package com.mycompany.quickchatapp;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class QuickChatApp {

    // ================= USER DETAILS =================
    String storedUsername;
    String storedPassword;
    String firstName;
    String lastName;

    // ================= TOTAL MESSAGES =================
    static int totalMessages = 0;

    // ================= USERNAME VALIDATION =================
    public boolean checkUserName(String username) {

        return username.contains("_") && username.length() <= 5;
    }

    // ================= PASSWORD VALIDATION =================
    public boolean checkPasswordComplexity(String password) {

        return password.matches(
                "^(?=.*[A-Z])(?=.*[0-9])(?=.*[^a-zA-Z0-9]).{8,}$");
    }

    // ================= CELLPHONE VALIDATION =================
    public boolean checkCellPhoneNumber(String cellNumber) {

        return cellNumber.matches("^\\+27[6-8][0-9]{8}$");
    }

    // ================= REGISTER USER =================
    public String registerUser(String username,
            String password,
            String cellNumber,
            String firstName,
            String lastName) {

        this.storedUsername = username;
        this.storedPassword = password;
        this.firstName = firstName;
        this.lastName = lastName;

        return "User successfully registered.";
    }

    // ================= LOGIN USER =================
    public boolean loginUser(String username, String password) {

        return username.equals(storedUsername)
                && password.equals(storedPassword);
    }

    // ================= LOGIN STATUS =================
    public String returnLoginStatus(boolean status) {

        if (status) {

            return "Welcome "
                    + firstName
                    + " "
                    + lastName;

        } else {

            return "\"Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
    }

    // ================= MAIN METHOD =================
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        QuickChatApp system = new QuickChatApp();

        ArrayList<String> messages = new ArrayList<>();

        // ================= REGISTRATION =================
        System.out.println("===== REGISTRATION =====");

        System.out.print("Enter first name: ");
        String firstName = input.nextLine();

        System.out.print("Enter last name: ");
        String lastName = input.nextLine();

        // USERNAME
        String username;

        while (true) {

            System.out.print("Enter username: ");
            username = input.nextLine();

            if (system.checkUserName(username)) {

                System.out.println(
                        "Username successfully captured.");

                break;

            } else {

                System.out.println(
                        "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
            }
        }

        // PASSWORD
        String password;

        while (true) {

            System.out.print("Enter password: ");
            password = input.nextLine();

            if (system.checkPasswordComplexity(password)) {

                System.out.println(
                        "Password successfully captured.");

                break;

            } else {

                System.out.println(
                        "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            }
        }

        // CELLPHONE
        String cell;

        while (true) {

            System.out.print(
                    "Enter cellphone number (+27): ");

            cell = input.nextLine();

            if (system.checkCellPhoneNumber(cell)) {

                System.out.println(
                        "Cell phone number successfully added.");

                break;

            } else {

                System.out.println(
                        "Cell phone number incorrectly formatted or does not contain international code(+27).");
            }
        }

        // REGISTER USER
        System.out.println(
                system.registerUser(
                        username,
                        password,
                        cell,
                        firstName,
                        lastName));

        // ================= LOGIN =================
        boolean loggedIn = false;

        System.out.println("\n===== LOGIN =====");

        while (!loggedIn) {

            System.out.print("Enter username: ");
            String loginUser = input.nextLine();

            System.out.print("Enter password: ");
            String loginPass = input.nextLine();

            loggedIn = system.loginUser(
                    loginUser,
                    loginPass);

            System.out.println(
                    system.returnLoginStatus(loggedIn));
        }

        // ================= QUICKCHAT =================
        if (loggedIn) {

            System.out.println(
                    "\nWelcome to QuickChat.");

            System.out.print(
                    "How many messages would you like to send? ");

            int numMessages = input.nextInt();
            input.nextLine();

            int sentCount = 0;

            boolean running = true;

            // ================= MENU LOOP =================
            while (running) {

                System.out.println(
                        "\n===== QUICKCHAT MENU =====");

                System.out.println(
                        "Option 1) Send Messages");

                System.out.println(
                        "Option 2) Show recently sent messages");

                System.out.println(
                        "Option 3) Quit");

                System.out.print(
                        "Choose an option: ");

                int choice = input.nextInt();
                input.nextLine();

                switch (choice) {

                    // ================= OPTION 1 =================
                    case 1:

                        while (sentCount < numMessages) {

                            System.out.println(
                                    "\nMessage "
                                    + (sentCount + 1));

                            // RECIPIENT
                            System.out.print(
                                    "Enter recipient number: ");

                            String recipient =
                                    input.nextLine();

                            // VALIDATE RECIPIENT
                            if (!recipient.matches(
                                    "^\\+27\\d{9}$")) {

                                System.out.println(
                                        "Cell phone number incorrectly formatted or does not contain international code(+27).");

                                continue;
                            }

                            System.out.println(
                                    "Cell phone number successfully captured.");

                            // MESSAGE
                            System.out.print(
                                    "Enter message: ");

                            String message =
                                    input.nextLine();

                            // VALIDATE MESSAGE LENGTH
                            if (message.length() > 250) {

                                int extra =
                                        message.length() - 250;

                                System.out.println(
                                        "Message exceeds 250 characters by "
                                        + extra
                                        + ", please reduce the size.");

                                continue;

                            } else {

                                System.out.println(
                                        "Message ready to send.");
                            }

                            // GENERATE MESSAGE ID
                            Random random = new Random();

                            long idNumber =
                                    1000000000L
                                    + (long) (random.nextDouble()
                                    * 9000000000L);

                            String messageID =
                                    String.valueOf(idNumber);

                            // CREATE HASH
                            String[] words =
                                    message.split(" ");

                            String firstWord =
                                    words[0].toUpperCase();

                            String lastWord =
                                    words[words.length - 1]
                                            .toUpperCase();

                            String messageHash =
                                    messageID.substring(0, 2)
                                    + ":"
                                    + sentCount
                                    + ":"
                                    + firstWord
                                    + lastWord;

                            System.out.println(
                                    "Message Hash: "
                                    + messageHash);

                            // SEND OPTIONS
                            System.out.println(
                                    "\n1) Send Message");

                            System.out.println(
                                    "2) Disregard Message");

                            System.out.println(
                                    "3) Store Message");

                            int option =
                                    input.nextInt();

                            input.nextLine();

                            // SEND MESSAGE
                            if (option == 1) {

                                System.out.println(
                                        "Message successfully sent.");

                                totalMessages++;
                                sentCount++;

                            }
                            // DISREGARD MESSAGE
                            else if (option == 2) {

                                System.out.println(
                                        "Press 0 to delete the message.");
                            }
                            // STORE MESSAGE
                            else if (option == 3) {

                                System.out.println(
                                        "Message successfully stored.");

                                System.out.println(
                                        "Message stored in JSON file.");

                                totalMessages++;
                                sentCount++;
                            }
                            // INVALID OPTION
                            else {

                                System.out.println(
                                        "Invalid option.");
                            }

                            // DISPLAY MESSAGE DETAILS
                            String fullMessage =
                                    "\n===== MESSAGE DETAILS ====="
                                    + "\nMessage ID: "
                                    + messageID
                                    + "\nMessage Hash: "
                                    + messageHash
                                    + "\nRecipient: "
                                    + recipient
                                    + "\nMessage: "
                                    + message;

                            messages.add(fullMessage);

                            System.out.println(fullMessage);

                            // TOTAL MESSAGES
                            if (sentCount == numMessages) {

                                System.out.println(
                                        "\nTotal messages sent: "
                                        + totalMessages);

                                break;
                            }
                        }

                        break;

                    // ================= OPTION 2 =================
                    case 2:

                        System.out.println(
                                "Coming Soon.");

                        break;

                    // ================= OPTION 3 =================
                    case 3:

                        running = false;

                        System.out.println(
                                "Goodbye.");

                        break;

                    // ================= INVALID OPTION =================
                    default:

                        System.out.println(
                                "Invalid option.");
                }
            }
        }

        input.close();
    }
}